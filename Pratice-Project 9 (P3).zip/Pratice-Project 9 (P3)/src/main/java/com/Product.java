package com;

public class Product {
public void productInfo() {
	System.out.println("product info method");
}
}
