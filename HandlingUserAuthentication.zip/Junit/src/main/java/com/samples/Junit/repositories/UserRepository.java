package com.samples.Junit.repositories;

import org.springframework.data.repository.CrudRepository;

import com.samples.Junit.entities.User;




public interface UserRepository extends CrudRepository<User, Integer> {

    public User findByName(String name);
}