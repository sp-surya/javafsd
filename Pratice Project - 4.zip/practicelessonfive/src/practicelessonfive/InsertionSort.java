package practicelessonfive;

import java.util.*;
public class InsertionSort {
	 public static void main(String args[]) {
		  int n;  
			Scanner sc=new Scanner(System.in);  
			System.out.println("Enter the size of Array : ");
			n=sc.nextInt(); 
			int a[] = new int[100]; 
			System.out.println("Enter the elements of the array: ");  
			for(int i=0; i<n; i++)  
			{   
			a[i]=sc.nextInt();  
			}  
			System.out.println("Array before Sorting: "); 
			for (int i=0; i<n; i++)   
			{  
			System.out.print(a[i]+ " ");  
			} 
			System.out.println("\n");
	        for (int i = 1; i < n; ++i) {
	            int key = a[i];
	            int j = i - 1;
	  
	            /* Move elements of arr[0..i-1], that are
	               greater than key, to one position ahead
	               of their current position */
	            while (j >= 0 && a[j] > key) {
	                a[j + 1] = a[j];
	                j = j - 1;
	            }
	            a[j + 1] = key;
	        }
	        System.out.println("Array after Insertion Sorting : "); 
			for (int i=0; i<n; i++)   
			{  
			System.out.print(a[i]+ " ");  
			} 
			System.out.println("\n");
			sc.close();
}
}