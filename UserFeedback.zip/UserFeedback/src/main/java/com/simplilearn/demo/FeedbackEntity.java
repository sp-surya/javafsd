package com.simplilearn.demo;

public class FeedbackEntity {

	private String Username;
	private String Email;
	private String Feedback;
	//getters and setters
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String Username) {
		this.Username = Username;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String Email) {
		this.Email = Email;
	}
	public String getFeedback() {
		return Feedback;
	}
	public void setFeedback(String Feedback) {
		this.Feedback = Feedback;
	}
	
}