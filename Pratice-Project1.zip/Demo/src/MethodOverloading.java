
public class MethodOverloading {


		int add(int x, int y) {
			return x+y;
		}
		int add(int x, int y,int z) {
			return x+y+z;
		}
		float add(float x, float y) {
			return x+y;
		}
		
		double add(double x, double y) {
			return x+y;
		}
		
		 
		
		public static void main(String[] args) {
			MethodOverloading obj= new MethodOverloading();
			System.out.println("12 + 4 = "+obj.add(12, 4));
			System.out.println("32.1 + 11.3 = "+obj.add(32.1f,11.3f));
			System.out.println("Add of 2 double = "+obj.add(5.2, 4.2));
			System.out.println("Add of 3 integer =s "+obj.add(2, 5 ,4));
			
		}
	}


