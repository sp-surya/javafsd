import java.util.HashSet; 

public class Hashsetmethod {


			public static void main(String[] args) {
				HashSet <Integer> set = new HashSet<Integer>();
				
				set.add(10);
				set.add(45);
				set.add(6);
				set.add(98);
				set.add(76);
				set.add(23);
				set.add(null);
				
				System.out.println("Size of the set is: "+set.size());
				
				System.out.println(set);
				
				System.out.println("Is contain there in the set: "+ set.contains(98));
				
				set.remove(null);
			
			}

		}


