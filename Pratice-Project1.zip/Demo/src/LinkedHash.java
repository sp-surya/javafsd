import java.util.LinkedHashSet; 

public class LinkedHash {
	

			public static void main(String[] args) {
				
				LinkedHashSet<String> linkedset= new LinkedHashSet<String>();
				
				linkedset.add("O");
				linkedset.add("P");
				linkedset.add("Q");
				linkedset.add("R");
				linkedset.add("S");
				linkedset.add("T");
				linkedset.add(null);
				
				System.out.println("Size of the List : "+linkedset.size());
				
				System.out.println(linkedset);
				
				
				System.out.println("S is there : "+linkedset.contains("S"));
				
				linkedset.remove(null);
				
				System.out.println("After Remove the element: "+linkedset);
				
			}

		}

