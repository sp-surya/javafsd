
public class EmployeeDetails {
	int empId;
	String empName;
	String department;
	float salary;
	public EmployeeDetails() {
		empId=12345;
		empName="XYZ";
		department="Sales";
		salary=50000;
	}
	public EmployeeDetails(int empId,String empName,String department,float salary) {
		this.empId=empId;
		this.empName=empName;
		this.department=department;
		this.salary=salary;
	}
	
	public void display() {
		System.out.println("Employee Id: "+empId);
		System.out.println("Employee Name: "+empName);
		System.out.println("Employee Department: "+department);
		System.out.println("Employee Salary: "+salary);
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		EmployeeDetails e= new EmployeeDetails();
		EmployeeDetails e1= new EmployeeDetails(67890, "ABC", "Cybersecurity", 60000); 
		e.display();
		e1.display();
		
		 
	
	}

	
}


