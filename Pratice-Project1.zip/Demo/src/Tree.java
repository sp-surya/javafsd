import java.util.Set;
import java.util.TreeSet;

public class Tree {

			
			public static void main(String[] args) {
				Set<String> set = new TreeSet<String>(); 
				
				set.add("Apple");
				set.add("Mango");
				set.add("Strawberry");
				set.add("Pineapple");
				set.add("Banana");
				System.out.println(set);
				
				System.out.println("Size of the tree : "+set.size());
				
				System.out.println("Banana is there : "+ set.contains("Banana"));
			}

		}

