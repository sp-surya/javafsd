
public class Access_modifiers {
	

		public void methodPublic() {
			System.out.println("Public method");
		}
		
		private void methodPrivate() {
			System.out.println("Private method");
		}
		
		void methodDefault() {
			System.out.println("Default method");
		}
		
		protected void methodProtected() {
			System.out.println("Protected method");
		}
		
		public static void main(String [] args) {
			
			 Access_modifiers mod= new   Access_modifiers();
			
			mod.methodDefault();
			mod.methodPrivate();
			mod.methodProtected();
		    mod.methodPublic();
			
		
		}
	}


