import java.util.LinkedList;

public class Linkedlist {
	


				public static void main(String[] args) {
					
					LinkedList<Integer> list= new LinkedList<Integer>();
					
					list.add(34);
					list.add(12);
					list.add(78);
					list.add(94);
					list.add(67);
					
					System.out.println("Size of the list : "+list.size());
					System.out.println(list);
					
					list.remove(4);
					
					System.out.println(list);
					
					System.out.println("2 th elemet: "+list.get(1));
					list.add(2,0);
					
					System.out.println(list);
					
					System.out.println("First element of the List: "+list.getFirst());
					
					System.out.println("Last element List : "+list.getLast());
					
					
					
				}

	}

