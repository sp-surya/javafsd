import java.util.PriorityQueue;
public class Priority {
	
				public static void main(String[] args) {
					
					PriorityQueue<Integer> priority= new PriorityQueue<Integer>(); 
					
					priority.add(78);
					priority.add(66);
					priority.add(23);
					priority.add(16);
					System.out.println(priority);
					System.out.println("Top Element: " + priority.peek());
					System.out.println("Printing the top element and removing: "+priority.poll());
					System.out.println(priority);
					System.out.println("Top Element: " + priority.peek());
					priority.remove(23);
					System.out.println("After Remove : "+priority);
				}

	}

