
public class Typecasting {

		public static void main(String[] args) {
			System.out.println("Implicit TypeCasting");
			char a= 'A';
			int b=a;
			System.out.println("a value = "+ a);
			System.out.println("b value = "+ b);
			System.out.println("\n");
			System.out.println("Explicit Typecasting");
			int c =50;
			char d = (char) c;
			System.out.println("c value = "+ c);
			System.out.println("d value = "+ d);
			
		}
	}


