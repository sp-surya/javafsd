import java.util.Iterator;
import java.util.Vector;

public class Vector_demo {
 
		public static void main(String[] args) {
				
				
				Vector<String> list= new Vector<String>();
				
				
				
				System.out.println("Size of the list:"+list.size());
				
				list.add("Car");
				list.add("Bike");
				list.add("Lorry");
				list.add("Van");// duplicate value are allowed in list
				list.add(null);// list contains null value
				
				System.out.println("After Adding an Elements :"+list.size());
				System.out.println(list);
				
				System.out.println("Element at index 4: "+list.get(4));
				list.add("Aeroplane");
				
				System.out.println(list);
				
				System.out.println("List Contains Bicycle :"+list.contains("Bycycle"));
				
				
				list.remove(0);
				list.remove(null);
				
				System.out.println(list);
				
				
				//print a list using for loop
				
				for(String s:list) {
					System.out.println("In For Loop: "+s);
				}
				
				
				//iterate using iterator
				Iterator<String> itr= list.iterator();
				
				while(itr.hasNext()) {
					System.out.println("In Iterator: "+itr.next());
				}
			
			}

	}


