
public class ClassMethod {

		public void print() {
			System.out.println("Without return type & without parameter");
		}
		
		//method returning nothing with 1 parameter
		public void display(String name) {
			
			System.out.println("Name : "+name);
		}
		
		
		//method with return type and parameter
		public double triangle(int b,int h) {
			
			return 0.5*b*h;
		}
		//method return string with two parameters
		public String fullName(String firstname, String lastname) {
			return firstname+" "+lastname;
		}
		 
		public static void main(String[] args) {
			
			ClassMethod obj= new ClassMethod();
			obj.print();
			obj.display("Arul");
			
			double triangle=obj.triangle(12,20);
			System.out.println("Area of the triangle = "+triangle);
			
			String MyName=obj.fullName("Arul", "Mozhi");
			System.out.println("Name : "+MyName);
			
			
		}

	}

