
public class CreatingAnotherThread {
	public void run(){  
		System.out.println("Thread Creation by implementing Runnable interface");  
		}  
		  
		public static void main(String args[]){  
			 CreatingAnotherThread m1=new  CreatingAnotherThread();  
		Thread t1 =new Thread(m1); 
		t1.start();  
		 }  
		}

