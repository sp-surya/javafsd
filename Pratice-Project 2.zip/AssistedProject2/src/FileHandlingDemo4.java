
public class FileHandlingDemo4 {
	static void verify(int num) throws Exception
	{
		if(num>0)
			System.out.println("Positive Interger");
		else
			System.out.println("Valid Age for Voting");
	}

	static void test() throws Exception
	{
		verify(20);
	}
	
	public static void main(String[] args) {
		
		 try {
			test();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
