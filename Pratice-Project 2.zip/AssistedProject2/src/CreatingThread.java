
public class CreatingThread  extends Thread{
 
			public void run(){  
				System.out.println("JThread Created by extending Thread ");  
				}  
				public static void main(String args[]){  
					CreatingThread th=new CreatingThread();  
				th.start();  
				 }  
				
	}


