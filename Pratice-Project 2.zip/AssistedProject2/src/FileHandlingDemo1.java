
public class FileHandlingDemo1 {
	
		public static void main(String[] args) {
			 
					String str="s";
					int number;
						try {
							number=Integer.parseInt(str);
							System.out.println("Number is "+number);
						}
						catch (Exception e) {
							System.out.println("Exception Occured: "+e);
						}
		}
	}

