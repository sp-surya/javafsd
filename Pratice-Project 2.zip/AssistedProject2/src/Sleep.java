
public class Sleep {
	
		private static Object LOCK = new Object();
		 
		public static void main(String[] args)
		  throws InterruptedException {
		  
		    Thread.sleep(5000);
		   
		    System.out.println("Thread '" + Thread.currentThread().getName() +"'  after sleeping for 5 second");
		      
		  
		    synchronized (LOCK)
		    {
		        LOCK.wait(1000);
		       
		        System.out.println("Object '" + LOCK + "' is wakeup after" +" waiting for 5 second");
		          
		    }
		}
	}

