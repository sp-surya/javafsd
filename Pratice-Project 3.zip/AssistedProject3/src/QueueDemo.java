import java.util.*;
public class QueueDemo {

	public static void main(String[] args) {
		Queue<String> positionQueue = new LinkedList<>();
		positionQueue.add("Car");
  		positionQueue.add("Bike");
  		positionQueue.add("Lorry");
  		positionQueue.add("Bus");
  		positionQueue.add("Van");
  		System.out.println("The Queue is  : " + positionQueue);
  		System.out.println("Head of The Queue : " + positionQueue.peek());
  		positionQueue.remove();
  		System.out.println("After removing Head  : " + positionQueue);
  		System.out.println("Size of The Queue : " + positionQueue.size());
	}

	}


