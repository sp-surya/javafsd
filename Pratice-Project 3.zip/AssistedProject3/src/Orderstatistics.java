class nthSmallstNumber 
{ 
int nthSmallestNumber(int arr[], int l, int r, int a) 
    	{ 
             		if (a > 0 && a <= r - l + 1) 
        		{ 
            			int position = randomPartition(arr, l, r); 
            			if (position-l == a-1) 
                			return arr[position]; 
            			if (position-l > a-1) 
                			return nthSmallestNumber(arr, l, position-1, a); 
            			return nthSmallestNumber(arr, position+1, r, a-position+l-1); 
        		} 
        return Integer.MAX_VALUE; 
    } 
    void swap(int arr[], int i, int j) 
    { 
        int temp = arr[i]; 
        arr[i] = arr[j]; 
        arr[j] = temp; 
    } 
    int partition(int arr[], int l, int r) 
    { 
        int x = arr[r], i = l; 
        for (int j = l; j <= r - 1; j++) 
        { 
            if (arr[j] <= x) 
            { 
                swap(arr, i, j); 
                i++; 
            } 
        } 
        swap(arr, i, r); 
        return i; 
    } 
    int randomPartition(int arr[], int l, int r) 
    { 
        int n = r-l+1; 
        int pivot = (int)(Math.random()) * (n-1); 
        swap(arr, l + pivot, r); 
        return partition(arr, l, r); 
    } 
}  

public class Orderstatistics {

	public static void main(String[] args) {
		nthSmallstNumber ob = new nthSmallstNumber(); 
        int arr[] = {8, 5, 74, 32, 3, 44, 96}; 
        int n = arr.length,a = 5; 
        System.out.println(a+" th smallest element is "+ ob.nthSmallestNumber(arr, 0, n-1, a)); 
    }

	}


